# -*- coding: utf-8 -*-

__about__ = """
This project demonstrates group functionality and the tasks, wiki and topics
apps. It is intended to be the starting point for things like code project
management where each code project gets its own wiki, task tracking system
and threaded discussions.
"""
