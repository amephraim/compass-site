# -*- coding: utf-8 -*-

__about__ = """
This project demonstrates a closed site requiring an invitation to join and
not exposing any information publicly. It provides a top-level task tracking
system, wiki and bookmarks. It is intended to be the starting point of sites
like intranets.
"""
