# -*- coding: utf-8 -*-

__about__ = """
This project demonstrates the use of a waiting list and signup codes for
sites in private beta. Otherwise it is the same as basic_project.
"""
